function randomPublicIP() {
  const avoidRanges = [[10], [192], [172]];
  function isPrivate(a, b) {
    return avoidRanges.some(([r]) => a === r || (a === 172 && b >= 16 && b <= 31));
  }

  let a, b, c, d;
  do {
    a = Math.floor(Math.random() * 223) + 1;
    b = Math.floor(Math.random() * 256);
    c = Math.floor(Math.random() * 256);
    d = Math.floor(Math.random() * 256);
  } while (isPrivate(a, b));

  const ports = [3128, 8080, 8888, 1080, 80];
  const port = ports[Math.floor(Math.random() * ports.length)];
  return `http://${a}.${b}.${c}.${d}:${port}`;
}

module.exports = () => randomPublicIP();
