let cycleStart = Date.now();
let blackoutWindow = { start: null, end: null };
const cycleDays = 3;

function generateBlackoutWindow() {
  const r = v => Math.floor(Math.random() * v);
  const t = h => {
    const d = new Date(); d.setHours(h + r(1), r(60), r(60)); return d.getTime();
  };
  blackoutWindow = { start: t(3), end: t(5) };
}

function shouldSleepNow() {
  const now = Date.now();
  const daysElapsed = (now - cycleStart) / (24 * 60 * 60 * 1000);
  const inWindow = now >= blackoutWindow.start && now <= blackoutWindow.end;
  return daysElapsed >= cycleDays && inWindow;
}

function resetCycle() {
  cycleStart = Date.now();
  generateBlackoutWindow();
}

module.exports = { shouldSleepNow, resetCycle, blackoutWindow };