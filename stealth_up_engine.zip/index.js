require("dotenv").config();
const express = require("express");
const axios = require("axios");
const getProxy = require("./rotate_ip");
const { shouldSleepNow, resetCycle, blackoutWindow } = require("./utils/runtimeController");

const app = express();
app.use(express.json());

const UP_TOKEN = process.env.UP_API_KEY;
const HEADERS = { Authorization: `Bearer ${UP_TOKEN}` };

resetCycle();

async function sendRoundupInjection(amount) {
  const roundUp = Math.ceil(amount) - amount;
  if (roundUp <= 0) return;

  const proxy = getProxy();
  try {
    await axios.post(
      "https://api.up.com.au/api/v1/transfers",
      {
        data: {
          type: "transfer",
          attributes: {
            amount: {
              currency: "AUD",
              value: roundUp.toFixed(2),
            },
            description: `Round-up Inject [${amount}]`,
            targetAccountId: "your_saver_id_here"
          }
        }
      },
      {
        headers: {
          ...HEADERS,
          "Content-Type": "application/json"
        },
        proxy: {
          host: proxy.split("://")[1].split(":")[0],
          port: parseInt(proxy.split(":")[2])
        }
      }
    );
    console.log(`✅ Injected $${roundUp.toFixed(2)} via ${proxy}`);
  } catch (err) {
    console.log("❌ Failed:", err.message);
  }
}

app.post("/webhook", async (req, res) => {
  const tx = req.body.data?.attributes;
  if (!tx) return res.sendStatus(400);

  const amount = parseFloat(tx.amount.value);
  if (!amount || amount > 1000) return res.sendStatus(204);

  if (shouldSleepNow()) {
    console.log("⏱️ Sleeping due to blackout window:", new Date().toLocaleTimeString());
    await new Promise(r => setTimeout(r, blackoutWindow.end - Date.now()));
    resetCycle();
  }

  await sendRoundupInjection(amount);
  res.sendStatus(200);
});

app.listen(3000, () => console.log("🧠 Webhook Engine running on port 3000"));